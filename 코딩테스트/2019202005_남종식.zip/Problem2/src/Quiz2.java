import java.sql.SQLOutput;
import java.util.Scanner;

public class Quiz2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input the number for Center");
        int a = scanner.nextInt();

        int [][] sudoku = new int[3][3];
        sudoku= new int[][]{
                {4, 9, 2},
                {3, a, 7},
                {8, 1, 6}
        };
        for (int i = 0; i < sudoku.length; i++) {
            for (int j = 0; j < sudoku[i].length; j++)
            {
                System.out.print(sudoku[i][j]+" ");
            }
            System.out.println(" ");
        }

        int sum1=0;
        int sum2=0;
        int sum3=0;

        for (int i = 0; i < sudoku.length; i++)
        {
            sum1+=(sudoku[0][i]);
        }

        for (int i = 0; i < sudoku.length; i++)
        {
            sum2+=(sudoku[1][i]);
        }

        for (int i = 0; i < sudoku.length; i++)
        {
            sum3+=(sudoku[2][i]);
        }

        if((sum1 == sum2) && (sum1 == sum3))
        {
            System.out.println("Gotcha!");
        }
        else
        {
            System.out.println("Wrong answer!");
        }





        }


//        for (int i = 0; i < sudoku.length; i++)
//            sum1 += sudoku[i];

}