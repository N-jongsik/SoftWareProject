import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

public class Quiz4 {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        String input = "Good Luck for the Coding Test!";
        StringTokenizer st = new StringTokenizer(input, " ");
        while(st.hasMoreElements())
        {
            list.add(st.nextToken());
        }

        Iterator<String> it = list.iterator();

        while(it.hasNext())
        {
            System.out.println(it.next());
        }

    }

}
