import java.util.Iterator;
import java.util.Vector;

public class Quiz5 {
    public static void main(String[] args) {
        String info [][]=new String[2][6];
        info = new String[][]
        {
            {"Computer Network","A"},
            {"Signal Processing","B"},
            {"Java","C"},
            {"C language","D"},
            {"Data Structure","E"},
            {"Database","F"}
        };

        StudentInfo st = new StudentInfo();

        Vector<StudentInfo> v = new Vector<>();

        void printVector(Vector<StudentInfo> v)
        {
            Iterator<String> it = st.iterator();
        }

        Vector<StudentInfo> sortVector (Vector<StudentInfo>)

        int findVector(Vector<>)




    }
}
