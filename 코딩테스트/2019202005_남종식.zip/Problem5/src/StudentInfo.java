public class StudentInfo {
    private String subject;
    private String grade;

    StudentInfo(String subject, String grade)
    {
        this.subject=subject;
        this.grade=grade;
    }
    void setGrade(String grade)
    {
        this.grade=grade;
    }

    String getSubject()
    {
        return subject;
    }

    String getGrade()
    {
        return grade;
    }
}
