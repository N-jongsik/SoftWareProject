package lib;

public class Triangle {
    int a;
    int b;
    int c;

    public Boolean TriangleCondition(int a, int b, int c)
    {
        this.a=a;
        this.b=b;
        this.c=c;

        if((a+b>c) && (b+c>a) && (c+a>b))
        {
            return true;
        }
        else
            return false;
    }

    public Boolean RightTriangle(int a, int b,int c)
    {
        this.a=a;
        this.b=b;
        this.c=c;

        if(c>a && c>b)
        {
             if((c*c)==(a*a)+(b*b))
             {
                 return true;
             }
             else
                 return false;
        }
        else
            return  false;
    }
    public Boolean EquilateralTriangle(int a, int b,int c)
    {

        this.a=a;
        this.b=b;
        this.c=c;

        if(a==b && b==c)
        {
            return true;
        }
        else
            return false;
    }

}
