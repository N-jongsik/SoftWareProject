import lib.Triangle;

import javax.swing.*;
import java.util.Scanner;

public class Quiz1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Input Three Integer >> ");
        int a= scanner.nextInt();
        int b= scanner.nextInt();
        int c= scanner.nextInt();

        Triangle t = new Triangle();
        Boolean A = t.TriangleCondition(a,b,c);
        Boolean B = t.RightTriangle(a,b,c);//직각
        Boolean C = t.EquilateralTriangle(a,b,c);//정


        if((A&&!B) && (A&&!C))
        {
            System.out.println("Three input numbers can make triangle");
        }
        if(!A)
        {
            System.out.println("Three input numbers can't make triangle");
        }
        if(A&&C)
        {
            System.out.println("Three input numbers can make equilateral triangle");
        }
        if(A&&B)
        {
            System.out.println("Three input numbers can make right triangle");
        }
        scanner.close();

    }
}
