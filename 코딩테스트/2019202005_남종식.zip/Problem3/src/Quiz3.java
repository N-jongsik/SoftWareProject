import java.util.Scanner;



public class Quiz3 {
    public static void main(String[] args) {

        System.out.println("이동거리를 입력하시오(단위:m)>>");
        Scanner scanner = new Scanner(System.in);
        int path = scanner.nextInt();
        System.out.println("기본 택시 요금은 5000입니다.");
        System.out.println("모범 택시 요금은 6500입니다.");


        scanner.close();


    }

}
