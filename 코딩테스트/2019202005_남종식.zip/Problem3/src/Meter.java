public interface Meter {
    default void distance(int distance){
        System.out.printf("이동거리는 %d 입니다.\n",distance);
    }

    public abstract int fare(int distance);
    public int getTotalFare();


    class Taxi implements Meter
    {

        @Override
        public int fare(int distance) {

            return 0;
        }

        @Override
        public int getTotalFare() {
            return 0;
        }
    }

    class Deluxe implements Meter
    {

        @Override
        public int fare(int distance) {
            return 0;
        }

        @Override
        public int getTotalFare() {
            return 0;
        }
    }
}
