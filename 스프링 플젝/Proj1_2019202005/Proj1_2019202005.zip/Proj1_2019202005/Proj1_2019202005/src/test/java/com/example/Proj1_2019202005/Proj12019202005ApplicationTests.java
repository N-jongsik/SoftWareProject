package com.example.Proj1_2019202005;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Proj12019202005ApplicationTests {

	@Test
	void contextLoads() {
	}

}
